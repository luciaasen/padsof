## Synopsis

This is Lucia and Juans project for the moon application

## Execution

Execute the main in mainMoon class (in main package) to see how the app works. Some students and a teacher are already added to the academy.

## Teacher credentials

Password: IsALotOfWork13579
Email: tea.cher@edu.es

## Sample student credentials 

Password: M
Email: l.a@m.es

## Contributors

Juan Riera and Lucia Lucia Asencio

