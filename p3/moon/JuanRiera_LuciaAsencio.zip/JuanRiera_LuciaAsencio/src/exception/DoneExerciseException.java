/**
 * 
 */
package exception;

/**
 * @author lucia
 *
 */
public class DoneExerciseException extends Exception{
	public String toString(){
		return "Uneditable, an exercise has been already done by a student";
	}
}
