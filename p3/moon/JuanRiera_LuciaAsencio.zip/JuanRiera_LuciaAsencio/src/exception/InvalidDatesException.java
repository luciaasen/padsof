/**
 * 
 */
package exception;

/**
 * @author lucia
 *
 */
public class InvalidDatesException extends Exception{
	public String toString(){
		return "Invalid dates, try again";
	}
}
