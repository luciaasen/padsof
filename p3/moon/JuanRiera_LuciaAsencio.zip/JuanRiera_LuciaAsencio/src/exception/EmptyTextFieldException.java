/**
 * 
 */
package exception;

/**
 * @author lucia
 *
 */
public class EmptyTextFieldException extends Exception{
	public String toString(){
		return "Found empty text field";
	}
}
