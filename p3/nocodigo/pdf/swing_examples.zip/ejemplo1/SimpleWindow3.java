package ejemplo1;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

class MyFrame extends JFrame {
	public MyFrame() {
		// crear ventana
		super("Mi GUI");

		// obtener contenedor, asignar layout
		Container contenedor = this.getContentPane();
		contenedor.setLayout(new FlowLayout());

		// crear componentes
		JLabel etiqueta = new JLabel("Nombre");
		final JTextField campo = new JTextField(10);
		JButton boton   = new JButton("Haz click");

		// asociar acciones a componentes
		boton.addActionListener(
		  new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		      JOptionPane.showMessageDialog(null, campo.getText());
		    }
		  }
		);

		// a�adir componentes al contenedor
		contenedor.add(etiqueta);
		contenedor.add(campo);
		contenedor.add(boton);

		// mostrar ventana
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(100,140);
		this.setVisible(true);
	}
}

public class SimpleWindow3 {

	public static void main(String[] args) {
		Runnable runner = new Runnable() {
			@Override public void run() {
				new MyFrame();
			}
		};
		EventQueue.invokeLater(runner);
	}

}
