package ejemplo4;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

class MyPanel extends JPanel implements ActionListener{
	private JPanel proximo;
	
	public MyPanel(String title, String but) {
		JLabel etiqueta  = new JLabel(title);
		this.setLayout(new BorderLayout());
		this.add(BorderLayout.CENTER, etiqueta);
		
		JButton boton = new JButton(but);
		boton.addActionListener(this);
		this.add(BorderLayout.SOUTH, boton);
		
		this.setVisible(false);
	}
	
	public void setProximo(JPanel p) {
		this.proximo = p;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (this.proximo!=null) {
			this.setVisible(false);
			this.proximo.setVisible(true);
		}		
	}
}

class MyFrame extends JFrame implements ActionListener {  	
	public MyFrame() {
		// crear ventana
		super("Mi GUI");

		Container contenedor = this.getContentPane();
		contenedor.setLayout(new FlowLayout());
		// crear pantalla 1
		MyPanel pantalla1 = new MyPanel("Pantalla 1", "siguiente");		
		// crear pantalla 2
		MyPanel pantalla2 = new MyPanel("Pantalla 2", "siguiente");
		// crear pantalla 3
		MyPanel pantalla3 = new MyPanel("Pantalla 3", "inicio");

		pantalla1.setProximo(pantalla2);
		pantalla2.setProximo(pantalla3);
		pantalla3.setProximo(pantalla1);

		// a�adir pantallas al contenedor
		contenedor.add(pantalla1);
		contenedor.add(pantalla2);
		contenedor.add(pantalla3);
		pantalla1.setVisible(true);

		// mostrar ventana
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(200,200);
		this.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("Hola!, has pulsado "+e.getActionCommand());		
	}
}

public class SimpleMult {

	public static void main(String[] args) {
		Runnable runner = new Runnable() {
			@Override public void run() {
				new MyFrame();
			}
		};
		EventQueue.invokeLater(runner);
	}

}
