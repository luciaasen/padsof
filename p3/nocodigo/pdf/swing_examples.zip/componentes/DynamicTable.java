package componentes;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DynamicTable extends JFrame {

	public DynamicTable() {
		// Create an array of column titles
		Object[] titles = {"name", "surnames", "mark", "passed"};
		        
		// Create a matrix of table contents
		Object[][] contents = {
		  {"Alba",   "Sanz",  new Double(5),   new Boolean(true)},
		  {"Bel�n",  "L�pez", new Double(3.2), new Boolean(false)},
		  {"Luisa",  "L�pez", new Double(4.5), new Boolean(false)},
		  {"Marcos", "P�rez", new Double(8.5), new Boolean(true)},
		  {"Miguel", "Vela",  new Double(7),   new Boolean(true)},
		  {"Sara",   "Valle", new Double(10),  new Boolean(true)},
		};
		        
		// Create a DefaultTableModel from the previous data
		DefaultTableModel dataModel = new DefaultTableModel(contents, titles);

		// Create the table, using the model as parameter
		JTable table = new JTable(dataModel);

		// Use the removeRow(<index>) method of the model to delete rows from the table
		dataModel.removeRow(0); // borra Alba

		// Use the addRow method of the model to add rows at the end of the table
		Object[] newRow = {"V�ctor", "T�llez", new Double(6), new Boolean(true)};
		dataModel.addRow(newRow);
		        
		// The insertRow(<index>,<object[]>) method of the model can also be used to insert a row in a specific position
		dataModel.insertRow(0, newRow);

		// Use the set(<object>,<row>,<column>) method of the model to modify the contents of the table
		dataModel.setValueAt("Juan", 1, 0); // Juan is substituted for Bel�n
		// Consider the possibility to create a scroll bar for the table just in case the number of rows is too big
		JScrollPane scrollBar = new JScrollPane(table);

		// Add the scroll bar to the panel where it will be shown
		JPanel tableExample = new JPanel();
		tableExample.add(scrollBar);
		
		JButton button = new JButton("Show");
		button.addActionListener( e -> { for (int i = 0; i<6; i++) 
											for (int j=0; j<4; j++) 
												System.out.println(contents[i][j]);});
		tableExample.add(button);

		this.setContentPane(tableExample);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(550,200);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		new DynamicTable();
	}

}
