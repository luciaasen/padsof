package componentes;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

public class JTreeExample extends JFrame{

	public JTreeExample() {
		// Create the root node, passing the text to be shown
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("Apuntes de PADS");

		// Create the tree, using its root node as argument
		final JTree tree = new JTree(root);
		tree.setPreferredSize(new Dimension(200,150));

		// By default the tree allows multiple node selection. Use the setSelectionModel method to activate single selection mode
		tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);

		// Use the add(<node>) method to add sons to any node of the tree
		root.add(new DefaultMutableTreeNode("subject 1"));  
		root.add(new DefaultMutableTreeNode("subject 2")); 
		DefaultMutableTreeNode folder = new DefaultMutableTreeNode("Examples folder");
		folder.add(new DefaultMutableTreeNode("example 1")); 
		root.add(folder);

		// Use a TreeSelectionListener to specify actions to be performed when a tree node is selected
		tree.addTreeSelectionListener(new TreeSelectionListener() {
		  public void valueChanged(TreeSelectionEvent e) {
		    // To get the node that has been selected:
		    // - if the selection mode is SINGLE_TREE_SELECTION, use the getLastSelectedPathComponent method
		    Object selectedNode = tree.getLastSelectedPathComponent();
		    // - if multiple selection is activated, use the getSelectionPaths / getSelectionRows methods
		    int[]      selectedNodesIndex = tree.getSelectionRows();
		    TreePath[] selectedNodesPath  = tree.getSelectionPaths();
		  }
		});

		// Consider the creation of a scroll bar for the tree just in case its size gets larger than expected
		JScrollPane scrollbar = new JScrollPane(tree);
		        
		// Add the scroll bar
		JPanel treeExample = new JPanel();
		treeExample.add(scrollbar);
		this.setContentPane(treeExample);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(230,180);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		new JTreeExample();
	}

}
