package componentes;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;

class Libro {
	private String titulo;
	private String autor;
	private boolean bueno;
	
	public Libro(String t, String n, boolean b) {
		this.titulo = t;
		this.autor = n;
		this.bueno = b;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public boolean isBueno() {
		return bueno;
	}

	public void setBueno(boolean bueno) {
		this.bueno = bueno;
	}
}

class LibrosTableModel extends AbstractTableModel {

	ArrayList<Libro> libros = new ArrayList<Libro>();
	
	public LibrosTableModel(Libro...libros) {
		this.libros.addAll(Arrays.asList(libros));
	}
	
	@Override
	public String getColumnName(int col) {
        switch (col) {
        case 0 : return "Libro";
        case 1 : return "Autor";
        case 2 : return "�Est� bien?";
        }
        return "";
    }

	@Override
	public int getColumnCount() {		
		return 3;
	}

	@Override
	public int getRowCount() {		
		return this.libros.size();
	}

	@Override
	public Object getValueAt(int row, int col) {
		Libro modif = this.libros.get(row);
		 switch (col) {
	        case 0 : return modif.getTitulo();
	        case 1 : return modif.getAutor();
	        case 2 : return modif.isBueno();
	    }	
		 return null;
	}
	
	public boolean isCellEditable(int row, int col)
    { return true; }

	public void setValueAt(Object value, int row, int col) {
		Libro modif = this.libros.get(row);
		 switch (col) {
	        case 0 : modif.setTitulo((String)value);
	        		 break;
	        case 1 : modif.setAutor((String)value);
	        		 break;
	        case 2 : modif.setBueno((Boolean)value);
	        		 break;
	    }		
		fireTableCellUpdated(row, col);
	}

    public Class<?> getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }
    
    public void addNewLibro(Libro b) {
    	this.libros.add(b);
    	this.fireTableRowsInserted(this.libros.size()-1, this.libros.size()-1);
    }
    
    public Libro getLibroAt(int idx) {
    	return this.libros.get(idx);
    }

    public void removeLibro(int idx) {
    	if (idx>=0) {
    		this.libros.remove(idx);
    		this.fireTableRowsDeleted(idx, idx);
    	}
    }
}

public class PruebaJTable extends JFrame implements ActionListener, ListSelectionListener {

	private JTextField 	libro = new JTextField(15),
						autor = new JTextField(10);
	private JCheckBox   gusta = new JCheckBox();
	private JTable 		tablaLibros;
	private LibrosTableModel libros;
	
	public PruebaJTable() {
		super("Tabla Din�mica con Objetos");
		
		JPanel norte = new JPanel();
		JPanel input = new JPanel(new GridLayout(0,2));
		input.add(new JLabel("Libro:"));
		input.add(libro);
		input.add(new JLabel("Autor:"));
		input.add(autor);
		input.add(new JLabel("Me gust�:"));
		input.add(gusta);
		norte.add(input);
		
		libros = new LibrosTableModel  (new Libro("Hablemos de Langostas", "David Foster Wallace", true),
										new Libro("Asfixia", "Chuck Palahniuk", true),
										new Libro("Menos que cero", "Breat Easton Ellis", true),
										new Libro("Planos de otro mundo", "Ryan Boudinot", true)); 
		
		JPanel medio = new JPanel();
		tablaLibros = new JTable(libros); 
		tablaLibros.getSelectionModel().addListSelectionListener(this);
		
		tablaLibros.setAutoCreateRowSorter(true);
		
		JScrollPane lista = new JScrollPane(tablaLibros);
		lista.setPreferredSize(new Dimension(500, 100));
		medio.add(lista);
		
		JPanel control = new JPanel();
		JButton anyade = new JButton("A�adir");
		JButton quita = new JButton("Quitar");
		anyade.addActionListener(this);
		quita.addActionListener(this);
		control.add(anyade);
		control.add(quita);
		
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(norte, BorderLayout.NORTH);
		this.getContentPane().add(medio, BorderLayout.CENTER);
		this.getContentPane().add(control, BorderLayout.SOUTH);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(new Dimension(515, 250));
        this.setVisible(true);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new PruebaJTable();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("A�adir")) {
			Libro nuevo = new Libro(this.libro.getText(), this.autor.getText(), this.gusta.isSelected());
			this.libros.addNewLibro(nuevo);
		}
		else  // quitar
		{
			int sel = this.tablaLibros.getSelectedRow();
			this.libros.removeLibro(sel);
		}
	}
	@Override
	public void valueChanged(ListSelectionEvent event) {
		if (event.getValueIsAdjusting()) {
            return;
        }
		int sel = this.tablaLibros.getSelectedRow();
		if (sel>-1) {
			Libro l = this.libros.getLibroAt(sel);
			if (l!=null) {
				this.autor.setText(l.getAutor());
				this.libro.setText(l.getTitulo());
				this.gusta.setSelected(l.isBueno());
			}
		}

	}

}
