package componentes;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

public class DynamicJTreeExample extends JFrame {

	public DynamicJTreeExample() {
		// Create the root node of the tree, using the corresponding text as argument
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("PADS notes");

		// Create the data model of the tree, using its root as argument
		DefaultTreeModel dataModel = new DefaultTreeModel(root);

		// Create the tree, using the data model as argument
		JTree tree = new JTree (dataModel);

		// The size of the tree can be fixed
		tree.setPreferredSize(new Dimension(200, 40));

		// Use the insertNodeInto method of the model to add sons to a node. Its arguments are the node to be inserted,
		// the parent node where it will be inserted and the position of the node among the sons
		dataModel.insertNodeInto(new DefaultMutableTreeNode("subject 1"), root, 0); // �subject 1" is the first son of root 
		dataModel.insertNodeInto(new DefaultMutableTreeNode("subject 2"), root, 1); // �subject 2" is the second son of root
		DefaultMutableTreeNode repository = new DefaultMutableTreeNode("examples repository");
		dataModel.insertNodeInto(repository, root, 2);                          //  �examples ..." is the third son of root
		dataModel.insertNodeInto(new DefaultMutableTreeNode("example 1"), repository, 0);  // �example 1" is the first
		                                                                                    // son of �example..." 

		// Use the removeFromParent(<node>) method to delete a node. Its sons will be deleted also
		//dataModel.removeNodeFromParent(repository); 

		// In order to modify the value of the selected node:
		TreePath path = tree.getSelectionPath();          // get the path to the selected node
		dataModel.valueForPathChanged(path, "subject 20");  // assign new value
		
		// Consider the creation of a scroll bar for the tree just in case its size gets larger than expected
		JScrollPane scrollbar = new JScrollPane(tree);
		        
		// Add the scroll bar
		JPanel treeExample = new JPanel();
		treeExample.add(scrollbar);
		this.setContentPane(treeExample);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(230,180);
		this.setVisible(true);

	}
	
	public static void main(String[] args) {
		new DynamicJTreeExample();
	}

}
