package componentes;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class PruebaRadioButton extends JFrame implements ActionListener, ItemListener {
	
	JRadioButton jrbs[] = {
			new JRadioButton("Sin calificar"),
			new JRadioButton("Suspenso"),
			new JRadioButton("Aprobado"),
			new JRadioButton("Notable"),
			new JRadioButton("Sobresaliente"),
			new JRadioButton("Matr�cula de Honor")
	};
	private JLabel nota = new JLabel("Nota: ");
	
	public PruebaRadioButton() {
		super("Radio Botones");
		this.nota.setName("nota");
		this.getContentPane().setLayout(new BorderLayout());
		JPanel botones = new JPanel();
		botones.setBorder(BorderFactory.createTitledBorder("Elige tu nota de PADS:"));
		botones.setLayout(new GridLayout(0,1));

		ButtonGroup bg = new ButtonGroup();
		
		for (JRadioButton b : jrbs) {
			bg.add(b);
			botones.add(b);
			b.addItemListener(this);
		}
		
		this.getContentPane().add(botones, BorderLayout.CENTER);
		
		JPanel wrap = new JPanel();
		JPanel sur = new JPanel();
		JButton jb = new JButton("OK");
		jb.addActionListener(this);
		
		sur.setLayout(new GridLayout(2,1));
		sur.add(this.nota);
		
		JPanel bot = new JPanel();
		bot.add(jb);
		
		sur.add(bot);		
		wrap.add(sur);
		this.getContentPane().add(wrap, BorderLayout.SOUTH);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(new Dimension(300, 250));
        this.setVisible(true);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new PruebaRadioButton();
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		for (JRadioButton b : this.jrbs) {
			if (b.isSelected()) {
				JOptionPane.showConfirmDialog(this, "Tienes un : "+b.getText());
				return;
			}
		}
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		String nota = ((JRadioButton)e.getSource()).getText();
		this.nota.setText("Nota : "+nota);
	}

}
