package componentes;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class PruebaJListDinamica extends JFrame implements ListSelectionListener,
															ActionListener
{

	private DefaultListModel<String> personasM;
	private JList<String> lista;
	private JLabel jl;
	
	public PruebaJListDinamica() {
		super("Selecciona una persona:");
		
		// Crear un DefaultListModel con los elementos de la lista
		personasM = new DefaultListModel<String>(); 
		personasM.addElement("ana");
		personasM.addElement("eduardo");
		personasM.addElement("esther");
		personasM.addElement("jos�");
		personasM.addElement("juan");
		personasM.addElement("luis");
		personasM.addElement("mar�a");
		personasM.addElement("miguel");
		personasM.addElement("zoe");

		
		lista= new JList<String>(personasM);	
		JScrollPane jsc = new JScrollPane(lista);
		
		lista.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		lista.setLayoutOrientation(JList.VERTICAL);
		lista.setVisibleRowCount(8);
		
		lista.addListSelectionListener(this);
		
		jsc.setPreferredSize(new Dimension(150, 100));
		
		JPanel jp = new JPanel();
		jp.add(new JLabel("Selecciona una persona:"));
		this.getContentPane().add(jp, BorderLayout.NORTH);
		
		JPanel jp1 = new JPanel();
		jp1.setLayout(new GridLayout(2,1));
		jl = new JLabel("Persona: ");
		jp1.add(jl);
		
		JPanel med = new JPanel();
		JButton borrar = new JButton("Borrar");
		med.add(borrar);
		jp1.add(med);
		borrar.addActionListener(this);
		this.getContentPane().add(jp1, BorderLayout.SOUTH);
				
		JPanel center = new JPanel();
		center.setLayout(new FlowLayout());
		center.add(jsc);
		this.getContentPane().add(center, BorderLayout.CENTER);		
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(new Dimension(300, 250));
        this.setVisible(true);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new PruebaJListDinamica();
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		if (!e.getValueIsAdjusting()) {
			String pers = (String)this.lista.getSelectedValue();
			if (pers!=null)	this.jl.setText("Persona :"+pers);
			else this.jl.setText("Persona :");
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		String pers = (String)this.lista.getSelectedValue();
		System.out.println("Borrando "+pers);
		this.personasM.removeElement(pers);
	}

}
