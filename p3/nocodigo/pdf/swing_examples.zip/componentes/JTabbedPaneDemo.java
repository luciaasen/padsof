package componentes;

import java.awt.Dimension;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;

public class JTabbedPaneDemo extends JFrame {

	private JTabbedPane pestanias;
		
	public JTabbedPaneDemo() {
		super("Pesta�as");
		
		pestanias = new JTabbedPane();
		ImageIcon icon = new ImageIcon("images/middle.gif");
		
		JComponent panel1 = new JLabel("Panel #1");
		pestanias.addTab("Tab 1", icon, panel1,
		                  "No hace nada...");
		pestanias.setMnemonicAt(0, KeyEvent.VK_1);
		
		JLabel label1 = new JLabel("Panel izquierdo");
		JLabel label2 = new JLabel("Panel derecho");
		JSplitPane panel2 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, label1, label2);
		//JSplitPane panel2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, label1, label2);
		pestanias.addTab("Tab 2", null, panel2,
		                  "Otro Panel");
		pestanias.setMnemonicAt(0, KeyEvent.VK_1);

		this.setContentPane(pestanias);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(300,200);
        this.setVisible(true);	
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new JTabbedPaneDemo();
	}


}
