package componentes;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

class MyPersonalizedModel extends AbstractTableModel {

	  // In this example table data are attributes of the class
	  private Object[] titles;
	  private Object[][] contents; 

	  // In this example the constructor initializes the attributes
	  public MyPersonalizedModel () { 
		// Create an array of column titles
		Object[] titles = {"name", "surnames", "mark", "passed"};
		this.titles = titles;
		        
		// Create a matrix of table contents
		Object[][] contents = {
		  {"Alba",   "Sanz",  new Double(5),   new Boolean(true)},
		  {"Bel�n",  "L�pez", new Double(3.2), new Boolean(false)},
		  {"Luisa",  "L�pez", new Double(4.5), new Boolean(false)},
		  {"Marcos", "P�rez", new Double(8.5), new Boolean(true)},
		  {"Miguel", "Vela",  new Double(7),   new Boolean(true)},
		  {"Sara",   "Valle", new Double(10),  new Boolean(true)},
		};
		this.contents = contents;
	  }

	  // The class must implement the getColumnCount, getRowCount and getValueAt methods
	  public int getColumnCount() { return this.titles.length; }          // Method that returns the number of columns
	  public int getRowCount()    { return this.contents.length; }            // Method that returns the number of rows
	  public Object getValueAt(int row, int col) { return this.contents[row][col]; } // Method that returns the contents of a cell

	  // By default the contents of the cells can not be edited. Overwrite the isCellEditable method to make them editable
	  public boolean isCellEditable (int row, int col) { return row==0; } // allows edition of the first row

	  // Overwrite the setValueAt method to specify how to change the value of cells
	  public void setValueAt (Object value, int row, int col) {
	    this.contents[row][col] = value;
	    fireTableCellUpdated(row, col);
	  }

	  // The getColumnName method can be overwritten to return the title of a column
	  public String getColumnName (int col) { return (String)titles[col]; }

	  // Cell data are rendered using the predefined format for the class returned by the getColumnClass method.
	  // Boolean data are shown by check boxes and numbers are aligned to the right (see figure).
	  public Class<?> getColumnClass (int col) { return getValueAt(0, col).getClass(); }
	}


public class PersonalizedTableExample extends JFrame {

	public PersonalizedTableExample() {
		// Create a DefaultTableModel from the previous data
		MyPersonalizedModel dataModel = new MyPersonalizedModel();
	
		// Create the table, using the model as parameter
		JTable table = new JTable(dataModel);
		
		// The setAutoCreateRowSorter method is used to activate rows reordering when the head of a column is clicked
		table.setAutoCreateRowSorter(true);

		// The class TableRowSorter can be used to filter table rows. The following example
		// filters the table so that only rows that contain the word �L�pez� in some cell are shown
		TableRowSorter<MyPersonalizedModel> filter = new TableRowSorter<>(dataModel);
		// TODO: Show the filter...
		//RowFilter<MyPersonalizedModel, Integer> rf = RowFilter.regexFilter("L�pez");
		//filter.setRowFilter(rf);
		table.setRowSorter(filter);

		JScrollPane scrollBar = new JScrollPane(table);

		// Add the scroll bar to the panel where it will be shown
		JPanel tableExample = new JPanel();
		tableExample.add(scrollBar);
		
		JButton button = new JButton("Show");
		button.addActionListener( e -> { System.out.println(dataModel);});
		tableExample.add(button);

		this.setContentPane(tableExample);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(550,200);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		new PersonalizedTableExample();
	}

}
