package componentes;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class PasswordField extends JFrame implements ActionListener {
	
	private JTextField usuario = new JTextField(10);
	private JPasswordField clave = new JPasswordField(10);
	
	public PasswordField() {
		super("Introduce tu usuario y contrase�a");
		this.getContentPane().setLayout(new BorderLayout());
		
		JPanel main = new JPanel();
		main.setBounds(100,100,400,350);
		main.setLayout(null);
		
		JLabel l1 = new JLabel("usuario:");
		l1.setBounds(10, 10, 100, 25);
		
		main.add(l1);
		
		usuario.setBounds(120, 10, 220, 25);
		main.add(usuario);
		
		JLabel l2 = new JLabel("clave:"); 
		l2.setBounds(10, 40, 100, 25);
		main.add(l2);
		
		clave.setBounds(120, 40, 220, 25);
		clave.addActionListener(this);
		
		main.add(clave);
		
		this.getContentPane().add(main);
		
		JButton confirmar = new JButton("OK");
		confirmar.addActionListener(this);
		JPanel  sur = new JPanel();
		
		sur.add(confirmar);
		
		this.getContentPane().add(BorderLayout.CENTER, main);
		this.getContentPane().add(BorderLayout.SOUTH, sur);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(new Dimension(380, 150));
        this.setVisible(true);
        this.setResizable(true);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new PasswordField();
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		String pwd = String.valueOf(this.clave.getPassword());
		
		JOptionPane.showMessageDialog(this, "Usuario: "+this.usuario.getText()+"\n"+
				                            "Clave: "+pwd);
	}

}
