package componentes;

import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

public class JTableExample extends JFrame {

	private Object[][] rows;
	
	public JTableExample() {
		super("Table example");
		// Create an array with the title of the columns
		String[] titles = {"name", "surname", "mark", "pass"};
		        
		// Create a matrix with the rows of the table
		Object[][] rows = {
		  {"Alba",   "Sanz",  new Double(5),   new Boolean(true)},
		  {"Belen",  "Lopez", new Double(3.2), new Boolean(false)},
		  {"Luisa",  "Lopez", new Double(4.5), new Boolean(false)},
		  {"Marcos", "Perez", new Double(8.5), new Boolean(true)},
		  {"Miguel", "Vela",  new Double(7),   new Boolean(true)},
		  {"Sara",   "Valle", new Double(10),  new Boolean(true)},
		};
		this.rows = rows;
		        
		// Create the table, using the rows and titles as parameters
		JTable table = new JTable(rows, titles);
//		JTable table = new JTable(rows, titles) {
//			private static final long serialVersionUID = 1L;
//
//			@Override
//			public boolean isCellEditable(int row, int column) {
//				return true;
//			}
//		};
		        
		// By default several rows of the table can be selected simultaneously.
		// If you want just one row to be selected, use the setSelectionMode method
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// The size of the table can be fixed 
		table.setPreferredScrollableViewportSize(new Dimension(500, 80));

		// Consider the possibility to create a scroll bar for the table just in case the number of rows is too big
		JScrollPane scrollBar = new JScrollPane(table);

		// Add the scroll bar to the panel where it will be shown
		JPanel tableExample = new JPanel();
		tableExample.add(scrollBar);
		
		JButton button = new JButton("Show");
		button.addActionListener( e -> { for (int i = 0; i<6; i++) 
											for (int j=0; j<4; j++) 
												System.out.println(this.rows[i][j]+" "+this.rows[i][j].getClass());});
		tableExample.add(button);

		this.setContentPane(tableExample);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(550,200);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		new JTableExample();
	}

}
