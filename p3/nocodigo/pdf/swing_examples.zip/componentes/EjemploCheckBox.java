package componentes;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class EjemploCheckBox extends JFrame implements ActionListener, ItemListener{
	private JCheckBox[] casillas = { new JCheckBox("pepino"), 
									 new JCheckBox("cebolla"), 
									 new JCheckBox("bacon"), 
									 new JCheckBox("queso")}; 
	
	public EjemploCheckBox() {
		super("Complementos");

		// Para cambiar el valor de una casilla, usar el m�todo setSelected
		this.casillas[0].setSelected(true);

		// A�adir las casillas al panel donde se quieran mostrar
		JPanel ejemploCheckbox = new JPanel(new GridLayout(5,1));
		ejemploCheckbox.add(new JLabel("Selecciona tus complementos"));
		for (JCheckBox c : this.casillas) {
			ejemploCheckbox.add(c);
			c.addItemListener(this);
		}
		
		// crear los botones
		JPanel botonera = new JPanel();
		JButton ok = new JButton("OK");
		JButton cancel = new JButton("Cancel");
		botonera.add(ok);
		botonera.add(cancel);
		
		ok.addActionListener(this);
		cancel.addActionListener(this);
		
		// a�adir los elementos
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(BorderLayout.CENTER, ejemploCheckbox);
		this.getContentPane().add(BorderLayout.SOUTH, botonera);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(new Dimension(250, 250));
        this.setVisible(true);
        //this.setResizable(true);
	}
	
	public static void main(String arg[]) {
		new EjemploCheckBox();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {
		case "OK":
			for (JCheckBox c : this.casillas)
				if (c.isSelected()) 
					System.out.println("La casilla "+c.getText()+" est� seleccionada");
			break;
		case "Cancel":
			System.out.println("Cancelling...");
			System.exit(0);
		}
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		JCheckBox cb = (JCheckBox)e.getSource();

		System.out.println("seleccion cambiada "+cb.getText()+" a "+cb.isSelected());
	}
}
