package componentes;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class PruebaJComboBox extends JFrame implements ItemListener{

	private String[] notas = { "Sin Calificar", "Suspenso", "Aprobado", "Notable", "Sobresaliente", "Matr�cula de Honor", "Sin Calificar", "Suspenso", "Aprobado", "Notable", "Sobresaliente", "Matr�cula de Honor" };
	//private Integer[] notas = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	private JComboBox<String> combo;
	private JLabel jl;
	
	public PruebaJComboBox() {
		super("Selecciona tu nota de PADS:");
		
		combo= new JComboBox<String>(notas);	
		
			
		JPanel jp = new JPanel();
		jp.add(new JLabel("Selecciona tu nota:"));
		this.getContentPane().add(jp, BorderLayout.NORTH);
		
		JPanel jp1 = new JPanel();
		jl = new JLabel("Nota: ");
		jp1.add(jl);
		this.getContentPane().add(jp1, BorderLayout.SOUTH);

		combo.addItemListener(this);
		combo.setSelectedIndex(2);
		
		JPanel center = new JPanel();
		center.setLayout(new FlowLayout());
		center.add(combo);
		this.getContentPane().add(center, BorderLayout.CENTER);		
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(new Dimension(300, 200));
        this.setVisible(true);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new PruebaJComboBox();
	}

	@Override
	public void itemStateChanged(ItemEvent arg0) {
		String nota = (String)this.combo.getSelectedItem();
		this.jl.setText("Nota :"+nota);
	}

}
