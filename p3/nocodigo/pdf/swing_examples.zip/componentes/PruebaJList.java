package componentes;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class PruebaJList extends JFrame implements ListSelectionListener{

	private String[] notas = { "Sin Calificar", "Suspenso", "Aprobado", "Notable", "Sobresaliente", "Matr�cula de Honor" };
	//private Integer[] notas = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	private JList<String> lista;
	private JLabel jl;
	
	public PruebaJList() {
		super("Selecciona tu nota de PADS:");
		
		lista= new JList<String>(notas);	
		JScrollPane jsc = new JScrollPane(lista);
		
		lista.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		lista.setLayoutOrientation(JList.VERTICAL);
		lista.setVisibleRowCount(8);
		
		lista.addListSelectionListener(this);
		
		jsc.setPreferredSize(new Dimension(150, 100));

		
		JPanel jp = new JPanel();
		jp.add(new JLabel("Selecciona tu nota:"));
		this.getContentPane().add(jp, BorderLayout.NORTH);
		
		JPanel jp1 = new JPanel();
		jl = new JLabel("Nota: ");
		jl.setName("label");
		jp1.add(jl);
				
		this.getContentPane().add(jp1, BorderLayout.SOUTH);
				
		JPanel center = new JPanel();
		center.setLayout(new FlowLayout());
		center.add(jsc);
		this.getContentPane().add(center, BorderLayout.CENTER);		
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(new Dimension(300, 200));
        this.setVisible(true);
        this.setName("window");
        this.setResizable(false);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new PruebaJList();
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		if (!e.getValueIsAdjusting()) {
			String nota = (String)this.lista.getSelectedValue();
			this.jl.setText("Nota :"+nota);
		}
	}

}
