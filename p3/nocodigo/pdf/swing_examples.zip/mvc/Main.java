package mvc;

import mvc.modelo.Proyecto;
import vista.VentanaTarea;

public class Main {

	public static void main(String[] args) {
		Proyecto pads = new Proyecto("PADS");
		
		new VentanaTarea(pads);
	}

}
