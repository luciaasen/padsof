package mvc.controladores;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import mvc.modelo.Proyecto;
import mvc.modelo.Tarea;

import vista.AltaTarea;

public class ControlAltaTarea implements ActionListener{
	private AltaTarea vista;
	private Proyecto modelo;

	public ControlAltaTarea(AltaTarea vista, Proyecto modelo) {
	   this.vista  = vista;
	   this.modelo = modelo;
	}

	@Override
	public void actionPerformed(ActionEvent evt) {

	   // validar valores en la vista
	   String nombreTarea = vista.getNombreTarea();
	   if (nombreTarea.equals("")) {
	       JOptionPane.showMessageDialog(vista, "Debe introducir un nombre.", "Error", JOptionPane.ERROR_MESSAGE);
	       return;
	   }
	   //String duracionTarea = vista.getDuracionTarea();
	   int duracion = vista.getDuracionTarea();
	   if (duracion < 0) return;
	   
	   // modificar modelo
	   Tarea tarea = new Tarea(nombreTarea, duracion);
	   modelo.addTarea(tarea);
	   
	   JOptionPane.showMessageDialog(vista, "Proyecto:\n"+modelo);

	   // mostrar nueva vista
	   /*DetalleProyecto nuevaVista = this.getPanelDetalleProyecto();
	   nuevaVista.update(tarea);
	   nuevaVista.setVisible(true);
	   vista.setVisible     (false);*/ // otra posibilidad es usar un CardLayout
	 }

}
