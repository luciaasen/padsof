package mvc.modelo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Proyecto {
	private String nombre;
	private Calendar start;
	private List<Tarea> tareas;
	
	public Proyecto(String n) {
		this.nombre = n;
		this.tareas = new ArrayList<Tarea>();
		this.start  = Calendar.getInstance();
	}
	
	public void addTarea (Tarea t ) {
		this.tareas.add(t);
	}
	
	@Override public String toString() {
		String ret = this.nombre;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		ret += "\nempieza = "+sdf.format(this.start.getTime());
		ret += "\ntareas:\n";
		for (Tarea t : this.tareas)
			ret += " - "+t+"\n";
		
		return ret;
	}
}
