package mvc.modelo;

public class Tarea {
	private String nombre;
	private int    duracion;
	
	public Tarea(String n, int d) {
		this.nombre   = n;
		this.duracion = d;
	}
	
	@Override public String toString() {
		return "Tarea "+this.nombre+" ("+this.duracion+" d�as)";
	}
}
