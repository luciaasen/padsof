package vista;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.InputVerifier;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AltaTarea extends JPanel {
	private JTextField nombreTarea;
	private JTextField duracionTarea;
	private JButton    botonAceptar;
	private JButton    botonCancelar;
	
	private JPanel construyeFormulario() {
		 JPanel inner = new JPanel();
		    
		 inner.setLayout(new GridLayout(0, 2));
		 // crear componentes
		 JLabel etiqueta = new JLabel("Nombre de la tarea: ");
		 nombreTarea     = new JTextField("t1", 10);
		 
		 JLabel etiqueta2 = new JLabel("Duracion de la tarea: ");
		 duracionTarea    = new JTextField("3", 3);

		 duracionTarea.setInputVerifier(new InputVerifier(){
			@Override
			public boolean verify(JComponent c) {
				String text = ((JTextField)c).getText();
				int duracion = 0;
				try { 
					duracion = Integer.valueOf(text);
				} catch(NumberFormatException e) {
				  JOptionPane.showMessageDialog(AltaTarea.this, "Debe introducir una duraci�n v�lida para la tarea.", "Error", JOptionPane.ERROR_MESSAGE);
				  return false;
				}
				return true;
			}
		 });
		    
		 inner.add(etiqueta);
		 inner.add(nombreTarea);
		 
		 inner.add(etiqueta2);
		 inner.add(duracionTarea);
		 
		 inner.setSize(new Dimension(300, 100));
		 
		 return inner;
	}
	
	private JPanel construyeBotonera() {
		JPanel botones = new JPanel();
		
		this.botonAceptar = new JButton("Aceptar");
		this.botonCancelar = new JButton("Cancelar");
		
		botones.add(this.botonAceptar);
		botones.add(this.botonCancelar);
		
		return botones;
	}
	
	public AltaTarea () {
	    JPanel inner = this.construyeFormulario();
	    JPanel botones = this.construyeBotonera();
	    
	    this.setLayout(new BorderLayout());
	    
	    this.add(BorderLayout.NORTH, inner);
	    this.add(BorderLayout.SOUTH, botones);
	    
	    this.setSize(new Dimension(300, 120));
	}

	// m�todo para asignar un controlador al bot�n
	public void setControlador(ActionListener c) {
        botonAceptar.addActionListener(c);
        duracionTarea.addActionListener(c);
	}

	// m�todo que devuelve el nombre de una tarea (contenido del campo JTextField)
	public String getNombreTarea () {
        return nombreTarea.getText();
    }
	
	public int getDuracionTarea () {
		if (duracionTarea.getInputVerifier().verify(duracionTarea))
			return Integer.valueOf(duracionTarea.getText());
		return -1;
    }
}
