package vista;

import java.awt.Dimension;

import javax.swing.JFrame;

import mvc.controladores.ControlAltaTarea;
import mvc.modelo.Proyecto;

public class VentanaTarea extends JFrame {
	
	private AltaTarea altas = new AltaTarea();
	
	public VentanaTarea(Proyecto p) {
		super("Alta Tareas");
		this.getContentPane().add(this.altas);
		
		ControlAltaTarea cat = new ControlAltaTarea(altas, p);
		this.altas.setControlador(cat);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setSize(new Dimension(300,130));
	}
}
