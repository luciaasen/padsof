package ejemplo3;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * Frame con m�ltiples paneles secuenciales
 * @author Juan de Lara
 */
class MyFrame extends JFrame implements ActionListener {  	
	public MyFrame() {
		// crear ventana
		super("Mi GUI");

		Container contenedor = this.getContentPane();
		contenedor.setLayout(new FlowLayout());
		// crear pantalla 1
		final JPanel pantalla1 = new JPanel();
		JButton boton = new JButton("siguiente");
		pantalla1.add(boton);
		pantalla1.setVisible(true);

		// crear pantalla 2
		final JPanel pantalla2 = new JPanel();
		JLabel etiqueta  = new JLabel("segunda pantalla");
		pantalla2.setLayout(new BorderLayout());
		pantalla2.add(BorderLayout.CENTER, etiqueta);
		pantalla2.setVisible(false);
		JButton boton2 = new JButton("anterior");
		pantalla2.add(BorderLayout.SOUTH, boton2);

		// pulsar el bot�n oculta la pantalla 1 y muestra la 2
		boton.addActionListener(
		  new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		      pantalla1.setVisible(false);
		      pantalla2.setVisible(true);
		    }
		  }
		);
		
		// pulsar el bot�n oculta la pantalla 1 y muestra la 2
		boton2.addActionListener(
		  new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		      pantalla1.setVisible(true);
		      pantalla2.setVisible(false);
		    }
		  }
		);

		// a�adir pantallas al contenedor
		contenedor.add(pantalla1);
		contenedor.add(pantalla2);

		// mostrar ventana
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(200,200);
		this.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("Hola!, has pulsado "+e.getActionCommand());		
	}
}

public class SimpleMult {

	public static void main(String[] args) {
		Runnable runner = new Runnable() {
			@Override public void run() {
				new MyFrame();
			}
		};
		EventQueue.invokeLater(runner);
	}

}
