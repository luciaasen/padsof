package ejemplo2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

class MyFrame extends JFrame implements ActionListener {  // Ejemplo de GridLayout	
	public MyFrame() {
		// crear ventana
		super("Mi GUI");

		JButton b0 = new JButton("(0,0)");
		JButton b1 = new JButton("(0,1)");
		JButton b2 = new JButton("(1,0)");
		JButton b3 = new JButton("(1,1)");
		
		JPanel jp = new JPanel();
		jp.setLayout(new GridLayout(2,2));
		this.getContentPane().add(jp);
		jp.add(b0);
		jp.add(b1);
		jp.add(b2);
		jp.add(b3);
		
		b0.addActionListener(this);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);

		// mostrar ventana
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(200,200);
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("Hola!, has pulsado "+e.getActionCommand());		
	}
}

public class Simple2 {

	public static void main(String[] args) {
		Runnable runner = new Runnable() {
			@Override public void run() {
				new MyFrame();
			}
		};
		EventQueue.invokeLater(runner);
	}

}
