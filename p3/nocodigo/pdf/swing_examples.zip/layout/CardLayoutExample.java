package layout;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Arrays;

import javax.swing.*;

public class CardLayoutExample extends JFrame implements ItemListener{

	// Cards panel declaration
	private JPanel cards; 
	final static String BUTTONPANEL = "Card with JButtons"; 
	final static String TEXTPANEL   = "Card with JTextField";
	// Create and initialize each card
	private JPanel card1 = new JPanel(); 
	private JPanel card2 = new JPanel();
	
	public void buildPanel1() {
		this.card1.setLayout(new FlowLayout());
		this.card1.add(new JButton("button 1"));
		this.card1.add(new JButton("button 2"));
		this.card1.add(new JButton("button 3"));
	}
	
	public void buildPanel2() {
		this.card2.add(new JTextField("JTextField", 20));
	}
	
	public CardLayoutExample() {
		// Create the panel that contains the cards
		cards = new JPanel(new CardLayout()); 
		cards.add(card1, BUTTONPANEL); 
		cards.add(card2, TEXTPANEL);
		
		this.buildPanel1();
		this.buildPanel2();
		
		JPanel comboBoxPane = new JPanel(); //FlowLayout is used by default
		String comboBoxItems[] = { BUTTONPANEL, TEXTPANEL }; 

		JComboBox<String> cb = new JComboBox<String>(comboBoxItems);   // Controls which card is shown

		cb.setEditable(false); 		       // Combo box used just for selection
		cb.addItemListener(this);		       // itemStateChanged to be called at selection
		comboBoxPane.add(cb); 		       // Add combo box to father panel
		JPanel pane = new JPanel();
		pane.setLayout(new BorderLayout());
		pane.add(comboBoxPane, BorderLayout.NORTH);    // Show the combo box
		pane.add(cards, BorderLayout.CENTER); 	       // Show cards panel

		this.setContentPane(pane);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(350,240);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		new CardLayoutExample();
	}

	@Override
	public void itemStateChanged(ItemEvent evt) {
		CardLayout cl = (CardLayout)(cards.getLayout());  // Get cards layout
		 cl.show(cards, (String)evt.getItem());   	// Show the card that corresponds to the
						     						// id chosen in the combo box.

	}
}
