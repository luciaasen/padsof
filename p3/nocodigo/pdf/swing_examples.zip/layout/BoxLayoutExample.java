package layout;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Container;


class BoxWindow extends JFrame {
	public BoxWindow() {
		super ("Ejemplo box layout");
		Container c = this.getContentPane();
		JPanel p = new JPanel();
		p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
		p.add(new JButton("hola"));
		p.add(Box.createRigidArea(new Dimension(20, 20)));
		p.add(new JButton("bot�n"));
		p.add(Box.createVerticalGlue());
		p.add(new JButton("adios"));
		p.add(Box.createVerticalGlue());
		p.add(new JButton("aaaa"));
		c.add(p);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setSize(new Dimension(200,200));
	}
}

public class BoxLayoutExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new BoxWindow();
	}

}
