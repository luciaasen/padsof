package layout;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class VentanaFormulario extends JFrame {

	private JPanel botonera       = new JPanel();
	private Formulario formulario = new Formulario(); // Hereda de JPanel
	private JButton ok            = new JButton("OK");
	private JButton cancel        = new JButton("Cancel");
	private JButton back          = new JButton("Back");
	  
	public VentanaFormulario() {
	    super("Un formulario Ejemplo");
	    Container cp = this.getContentPane();  	// Obtener el contenedor del Frame
	    cp.setLayout(new BorderLayout());		// Le ponemos un layout de borde

	    // La botonera (JPanel) tiene por defecto FlowLayout, as� que no hacemos nada
	    this.botonera.add(this.ok);	// En el flowlayout, los componentes se a�aden en orden,...
	    this.botonera.add(this.cancel);	// por defecto de izquierda a derecha...
	    this.botonera.add(this.back);	// si no hubiera espacio, se ponen en varias filas
	    
	    this.ok.addActionListener(new Controlador());
	    this.formulario.setController(new Controlador());

	    cp.add(botonera, BorderLayout.SOUTH);	// Colocamos la botonera al sur
	    cp.add(formulario, BorderLayout.CENTER);	// El formulario ir� en el centro

	    this.pack();		// Importante: hace que los subcomponentes se coloquen�
							// de acuerdo al layout y con sus tama�os preferidos.
	    this.setVisible(true);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public class Controlador implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent evt) {
			JOptionPane.showMessageDialog(VentanaFormulario.this, 
					"Evento producido por el comando "+evt.getActionCommand()+
					"\ncon fuente un objeto de tipo: "+evt.getSource().getClass());
		}		
	}

	
	public static void main(String[] args) {
		new VentanaFormulario();
	}

}

class Formulario extends JPanel {
	  private JLabel label, label2;
	  private JTextField field, field2;

	  public Formulario() {
	    SpringLayout layout = new SpringLayout();	// Layout basado en restricciones...
	    this.setLayout(layout);    			// muy flexible, pero de bajo nivel.
	    
	    // Componentes a colocar...
	    label  = new JLabel("Nombre: ");
	    field  = new JTextField("<nombre>", 15);
	    label2 = new JLabel("Edad: ");
	    field2 = new JTextField("<edad>", 5);

	    // La izquierda (WEST) de label estar� a 5 pixels de la izquierda del contenedor 
	    layout.putConstraint(SpringLayout.WEST, label, 5, SpringLayout.WEST, this);
	    // El norte (NORTH) de label estar� a 5 pixels del norte del contenedor 
	    layout.putConstraint(SpringLayout.NORTH, label, 5, SpringLayout.NORTH, this);

	    // La izquierda de field estar� a 5 pixels desde el borde derecho (EAST) de label
	    layout.putConstraint(SpringLayout.WEST, field, 5, SpringLayout.EAST, label);
	    // El norte de field estar� a 5 pixels desde el norte del contenedor
	    layout.putConstraint(SpringLayout.NORTH, field, 5, SpringLayout.NORTH, this);

	    // La izquierda de label2 estar� a 0 pixels (alineada) del borde izquierdo de label
	    layout.putConstraint(SpringLayout.EAST, label2, 0, SpringLayout.EAST, label);
	    // El norte de label2 estar� a 5 pixels del borde inferior (SOUTH) de label
	    layout.putConstraint(SpringLayout.NORTH, label2, 8, SpringLayout.SOUTH, label);

	    // La izquierda de field2 alienada con la izquierda de field
	    layout.putConstraint(SpringLayout.WEST, field2, 0, SpringLayout.WEST, field);
	    // El norte de field2, 5 pixels m�s abajo de field
	    layout.putConstraint(SpringLayout.NORTH, field2, 5, SpringLayout.SOUTH, field);

	    field2.setInputVerifier(new InputVerifier() {			
			@Override
			public boolean verify(JComponent jtf) {
				String text = ((JTextField)jtf).getText();
				try {
					Integer value = Integer.valueOf(text);
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(Formulario.this, "Error: se espera un n�mero");
					return false;
				}
				return true;
			}
		});
	    
	    this.add(label); this.add(field);
	    this.add(label2); this.add(field2);
	    this.setPreferredSize(new Dimension(250,50));	// importante: tama�o preferido de este panel
	    this.setVisible(true);  
	  }

	public void setController(VentanaFormulario.Controlador controlador) {
		field2.addActionListener(controlador);
	}
}

