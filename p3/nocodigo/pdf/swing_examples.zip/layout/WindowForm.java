package layout;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.*;

class Form extends JPanel {
	  private JLabel label, label2;
	  private JTextField field, field2;

	  public Form () {
	    SpringLayout layout = new SpringLayout();	// Layout based on restrictions ...
	    this.setLayout(layout);    			// Very flexible but low level.
	    
	    // Components to be located ...
	    label  = new JLabel("Name: ");
	    field  = new JTextField("<name>", 15);
	    label2 = new JLabel("Age: ");
	    field2 = new JTextField("<age>", 5);

	    // The left side of label will be located 5 pixels away from the left side of container
	    layout.putConstraint(SpringLayout.WEST, label, 5, SpringLayout.WEST, this);
	    // The upper side of label will be located 5 pixels away from the upper part of container
	    layout.putConstraint(SpringLayout.NORTH, label, 5, SpringLayout.NORTH, this);

	    // The left side of field will be located 5 pixels away from the right side of label
	    layout.putConstraint(SpringLayout.WEST, field, 5, SpringLayout.EAST, label);
	    // The upper side of the field will be located 5 pixels away from the upper side of container
	    layout.putConstraint(SpringLayout.NORTH, field, 5, SpringLayout.NORTH, this);

	    // The left side of label2 will be aligned with the left border of label
	    layout.putConstraint(SpringLayout.EAST, label2, 0, SpringLayout.EAST, label);
	    // The upper part of label2 will be located 5 pixels away from the lower border of label
	    layout.putConstraint(SpringLayout.NORTH, label2, 8, SpringLayout.SOUTH, label);

	    // The left side of field2 will be aligned with the left side of field
	    layout.putConstraint(SpringLayout.WEST, field2, 0, SpringLayout.WEST, field);
	    // El upper side of field2 will be located 5 pixels away from field.
	    layout.putConstraint(SpringLayout.NORTH, field2, 5, SpringLayout.SOUTH, field);

	    this.add(label); this.add(field); this.add(label2); this.add(field2);
	    this.setPreferredSize(new Dimension(250,50));	// important: preferred size for this panel
	    this.setVisible(true);  
	    }
	}


public class WindowForm extends JFrame {

	private JPanel buttonPanel = new JPanel();
	  private Form form          = new Form (); // Hereda de JPanel
	  private JButton ok         = new JButton("OK");
	  private JButton cancel     = new JButton("Cancel");
	  private JButton back       = new JButton("Back");

	  public WindowForm() {
	    super("An example form");
	    Container cp = this.getContentPane();  	// Get the Frame container
	    cp.setLayout(new BorderLayout());		// Add BorderLayout to it

	    // The button panel(JPanel) by default uses FlowLayout, so we do nothing
	    buttonPanel.add(ok);	// Components rendered with flow layout are shown ...
	    buttonPanel.add(cancel);	// by default from left to write �
	    buttonPanel.add(back);	// using new rows if there is not enough horizontal space

	    cp.add(buttonPanel, BorderLayout.SOUTH);	// Button panel located at South
	    cp.add(form, BorderLayout.CENTER);	// Form located at center

	    this.pack();		// Important: subcomponents are located according to �
				// layout using their prefered sizes.
	    this.setVisible(true);
	    this.setMinimumSize(new Dimension(250,150));	
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  }


	  public static void main(String[] args) {
		  new WindowForm();
	  }
}
