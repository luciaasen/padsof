package layout;

import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class FlowLayoutExample extends JFrame implements ActionListener{

	public FlowLayoutExample() {
		super("Flow Layout Example");
		Container p = this.getContentPane();
		FlowLayout f = new FlowLayout ();
		p.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		f.setAlignment(FlowLayout.LEFT);
		f.setHgap(30);
		p.setLayout (f);
		
		JButton[] botones = {new JButton ("Button 1"), new JButton ("Button 2"), 
							 new JButton ("Button 3"), new JButton ("Button 4"), 
							 new JButton ("Button 5")};
		
		for (JButton b : botones) {
			p.add(b);
			b.addActionListener(this);
		}
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setSize(new Dimension(450,200));
		this.setMinimumSize(new Dimension(450,200));
		this.setMaximumSize(new Dimension(450,200));
		this.setPreferredSize(new Dimension(450,200));
		//this.setResizable(false);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new FlowLayoutExample();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String res = JOptionPane.showInputDialog(this, "Entrada:", "hola");
		JButton newb = new JButton(res);
		this.getContentPane().add(newb);
		newb.addActionListener(this);		
		this.pack();
		this.doLayout();
	}

}
