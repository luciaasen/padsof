package layout;

import java.awt.ComponentOrientation;
import java.awt.GridLayout;

import javax.swing.*;

public class GridLayoutExample extends JFrame {

	public JPanel build() {
	   // Elements to be located in the container
	   JButton buttons[]={ new JButton("Table 0"),
			   new JButton("Table 1"),
			   new JButton("Table 2"),
			   new JButton("Table 3"),
			   new JButton("Table 4")
	   };
	
	   // Container where components are located
	   JPanel p = new JPanel();
	   // Set grid layout
	   p.setLayout(new GridLayout(0,2));
	   // Add buttons to container
	   for (JButton j : buttons) { 
	     p.add(j); // No parameters: buttons are
	   }	     // added following the natural
	 	     // order
	   // Change the default order used
	   p.applyComponentOrientation(
	    ComponentOrientation.RIGHT_TO_LEFT);
	
	   return p;
	}

	public GridLayoutExample() {
		this.setContentPane(this.build());
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(230,180);
		this.setVisible(true);
	}
	
	
	public static void main(String[] args) {
		new GridLayoutExample();
	}

}
