package layout;

import java.awt.BorderLayout;
import java.awt.ComponentOrientation;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class BorderLayoutExample extends JFrame {

	public JPanel build() {
		JPanel jp = new JPanel();
		// Add border layout
		jp.setLayout(new BorderLayout());

		// Create componets to be located in the panel
		JButton button1    = new JButton("NORTH");
		JButton button2    = new JButton("SOUTH");
		JButton button3    = new JButton("EAST");
		JButton button4    = new JButton("WEST");
		JButton button5    = new JButton("CENTER");

		// Add components
		jp.add(button1,  BorderLayout.NORTH);  // 2nd argument: position
		jp.add(button2,  BorderLayout.SOUTH);
		jp.add(button3,  BorderLayout.EAST);
		jp.add(button4,  BorderLayout.WEST);
		jp.add(button5,  BorderLayout.CENTER);


		return jp;
	}

		public BorderLayoutExample() {
			this.setContentPane(this.build());
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.setSize(230,180);
			this.setVisible(true);
		}
		
		
		public static void main(String[] args) {
			new BorderLayoutExample();
		}

}
